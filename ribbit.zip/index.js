require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder, ActivityType } = require('discord.js');
const cron = require('node-cron');

// 1. Setup Environment Logic
// To run in dev mode, use: NODE_ENV=development node index.js
const isDev = process.env.NODE_ENV === 'development';

const TOKEN = isDev ? process.env.DEV_TOKEN : process.env.PROD_TOKEN;
const DAILY_THEME_CHANNEL_ID = isDev ? process.env.DEV_CHANNEL_ID : process.env.PROD_CHANNEL_ID;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

// --- Data Lists ---
const modifiers = [
  // --- Your Originals ---
  "Bioluminescent", "Crystallized", "Clockwork", "Neon", "Haunted", "Forgotten", "Ancient", "Living", "Shattered", "Overgrown",
  "Celestial", "Cursed", "Hollow", "Gilded", "Spectral", "Submerged", "Fractured", "Eternal", "Burning", "Frozen",
  "Withered", "Radiant", "Corrupted", "Translucent", "Rusted", "Twisted", "Luminous", "Decayed", "Sacred", "Volcanic",
  "Serene", "Chaotic", "Mirrored", "Drifting", "Shimmering", "Forsaken", "Towering", "Whispering", "Crumbling", "Blazing",
  "Sunken", "Verdant", "Ashen", "Obsidian", "Phantom", "Colossal", "Tangled", "Sovereign", "Molten", "Iridescent",
  "Barren", "Shifting", "Glitching", "Feral", "Arcane", "Mechanical", "Primordial",
  // --- New Additions ---
  "Cybernetic", "Industrial", "Prismatic", "Ethereal", "Nebulous", "Gothic", "Cinematic", "Vaporwave", "Retro", "Mythical",
  "Starlit", "Opalescent", "Synthetic", "Impossible", "Geometric", "Velvet", "Static", "Floral", "Abyssal", "Monolithic"
];

const subjects = [
  // --- Your Originals ---
  "Forest", "Ocean", "Temple", "Carnival", "Civilization", "Machine", "Garden", "Archive", "Creature", "Tower",
  "Ritual", "Throne", "Ruin", "Dream", "Portal", "Vessel", "Labyrinth", "Oracle", "Bloom", "Void",
  "Cathedral", "Wasteland", "Specter", "Colossus", "Abyss", "Clocktower", "Shoreline", "Sanctum", "Behemoth", "Mirage",
  "Fortress", "Cavern", "Nebula", "Wraith", "Canopy", "Citadel", "Reef", "Monolith", "Ember", "Shipwreck",
  "Meadow", "Spire", "Tundra", "Altar", "Swamp", "Glacier", "Serpent", "Horizon", "Marketplace", "Observatory",
  "Graveyard", "Titan", "Battlefield", "Oasis", "Library", "Volcano", "Crown",
  // --- New Additions ---
  "Metropolis", "Outpost", "Sanctuary", "Greenhouse", "Relic", "Automaton", "Deity", "Artifact", "Monument", "Engine",
  "Key", "Tide", "Supernova", "Peak", "Grove", "Summit", "Android", "Space-Station", "Samurai", "Cyber-City"
];

// --- Helper Functions ---
function getDailyTheme() {
  // Picks a random item from each list every time it's called
  const modifier = modifiers[Math.floor(Math.random() * modifiers.length)];
  const subject = subjects[Math.floor(Math.random() * subjects.length)];
  
  return `${modifier} ${subject}`;
}

async function postDailyTheme(targetChannel = null) {
  try {
    // If no channel is passed (cron job), fetch the one from .env
    const channel = targetChannel || await client.channels.fetch(DAILY_THEME_CHANNEL_ID);
    
    if (!channel) return console.error("Could not find the channel!");

    const theme = getDailyTheme();
    const embed = new EmbedBuilder()
      .setTitle('🐸 Daily Art Theme')
      .setDescription(`## *${theme}*`)
      .setColor(isDev ? 0xFFA500 : 0x50C878) // Orange for Dev, Green for Prod
      .setFooter({ text: 'Create something amazing and share it with your friends!' });

    await channel.send({ embeds: [embed] });
  } catch (err) {
    console.error("Error posting theme:", err);
  }
}

// --- Event Listeners ---
client.once('ready', () => {
  const mode = isDev ? 'DEVELOPMENT' : 'PRODUCTION';
  console.log(`🐸 Ribbit is online as ${client.user.tag} [${mode} MODE]`);

  // Set a status so you know which is which
  client.user.setActivity({
    name: isDev ? 'Maintenance (Dev Mode)' : 'for !theme',
    type: ActivityType.Watching
  });

  // Schedule: 2:00 PM (14:00) Denver Time
  cron.schedule('0 14 * * *', () => {
    console.log(`[${new Date().toLocaleTimeString()}] Posting scheduled daily theme...`);
    postDailyTheme();
  }, {
    timezone: 'America/Denver'
  });

  console.log('📅 Daily theme scheduler is running!');
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Check for !theme or !testtheme
  if (message.content === '!theme' || message.content === '!testtheme') {
    
    // PERMISSION CHECK: Only allow Admins to run this
    if (!message.member.permissions.has('Administrator')) {
      return message.reply("🚫 Only Grandmaster WhiteFrog can call for a new theme!");
    }

    // If they ARE an admin, send the theme
    postDailyTheme(message.channel);
  }
  
  // --- NEW COMMAND: !ribbit ---
if (message.content === '!ribbit') {
    const mod = modifiers[Math.floor(Math.random() * modifiers.length)];
    const sub = subjects[Math.floor(Math.random() * subjects.length)];
    
    const ribbitEmbed = new EmbedBuilder()
        .setTitle('🐸 Ribbit! New Topic')
        .setDescription(`## *${mod} ${sub}*`)
        .setColor(0x9B59B6) // Purple for "Personal" topics
        .setFooter({ text: 'Got a better idea? Type !ribbit again!' });

    return message.reply({ embeds: [ribbitEmbed] });
}
});

client.login(TOKEN);